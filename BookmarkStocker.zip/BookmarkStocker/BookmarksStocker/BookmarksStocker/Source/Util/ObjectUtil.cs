﻿namespace BookmarksStocker.Source.Util
{
    public static class ObjectUtil
    {
        /*
        public static bool IsNullOrSpace(this string str)
        {
            bool result = string.Format("{0}", str).Replace(" ", "").Length == 0;
            return result;
        }

        public static bool IsNull(this object o)
        {
            return o == null;
        }

        public static bool IsNullOrDbNull(this object obj)
        {
            return (null == obj | obj == DBNull.Value);
        }

        public static string ToStr(this object obj)
        {
            return IsNullOrDbNull(obj) == true ? string.Empty : obj.ToString();
        }

        public static bool IsNullOrEmpty(this string str)
        {
            if (str == null)
            {
                return true;
            }
            else
            {
                return str.Length == 0;
            }
        }
        */
    }
}